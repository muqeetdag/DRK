/* =====================================================================
   OTC Bot — Live Scanner
   ---------------------------------------------------------------------
   A dense grid of every scanned pair: status (WAIT / BUY / SELL), trend
   from the algorithmic sequence factor, live confidence and the next
   execution minute. Cards update in place every few seconds.
   ===================================================================== */
(function () {
  'use strict';

  const { api } = window.OTC;
  const M = window.MARKET;
  const CLOCK = window.CLOCK || {
    istTime: (d) => new Date(d).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    istStamp: (d) => new Date(d).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
    istFull: (d) => new Date(d).toLocaleString('en-US'),
    istClock: () => '',
    mmss: (ms) => String(Math.max(0, Math.floor(ms / 1000))),
    plan: () => ({ entryMs: Date.now(), expiryMs: Date.now() + 60000, pending: false, leftMs: 60000 }),
    everySecond: (fn) => { fn(); return setInterval(fn, 1000); },
  };
  const TF_MS = 60000;
  const $ = (id) => document.getElementById(id);

  const SOURCE_KINDS = {
    live: ['forex', 'crypto', 'india'],
    otc: ['otc'],
  };

  const state = {
    kind: 'all',
    status: 'all',
    sources: new Set(['live', 'otc']),
    entries: new Map(),
    lastSignature: '',
    sound: false,
    cycle: 0,
  };

  /* --------------------------------------------------------------- utils */
  const pad = (n) => String(n).padStart(2, '0');
  const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

  function toast(html, cls = '') {
    const wrap = $('toasts');
    if (!wrap) return;
    const el = document.createElement('div');
    el.className = 'toast ' + cls;
    el.innerHTML = html;
    wrap.appendChild(el);
    setTimeout(() => el.remove(), 3800);
  }

  function beep() {
    if (!state.sound) return;
    try {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      const ctx = beep.ctx || (beep.ctx = new Ctx());
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.type = 'sine';
      o.frequency.value = 760;
      g.gain.setValueAtTime(0.0001, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.09, ctx.currentTime + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.24);
      o.connect(g).connect(ctx.destination);
      o.start();
      o.stop(ctx.currentTime + 0.28);
    } catch { /* ignore */ }
  }

  function hms(d = new Date()) {
    if (CLOCK.istClock) {
      const t = CLOCK.istClock(d);
      if (t) return t;
    }
    return `${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}`;
  }

  function timeLabel(d = new Date()) {
    return CLOCK.istTime(d);
  }

  /* every pair runs its own one-minute trade window: the entry prints a few
     seconds after the candle opens (staggered per pair) and the trade closes
     exactly one minute later. The schedule comes from the shared clock, so
     the Signals page shows the same entry stamp and the same seconds left.
     Stamps are printed to the second (04:51:07 PM) so they read as a fixed
     schedule and never as the ticking clock. */
  function tradeOf(id) {
    const plan = CLOCK.plan(id, TF_MS);
    return {
      plan,
      pending: plan.pending,
      /* live trade -> the candle it entered; standby -> the candle it opens
         next, which is always a real future minute (never the wall clock) */
      entry: CLOCK.istTime(plan.entryMs),
      left: CLOCK.mmss(plan.pending ? plan.toEntryMs : plan.toExpiryMs),
    };
  }

  /* the sequence factor is the engine's trend read; a live signal never
     contradicts its own direction, which is what made the arrows look wrong */
  function trendOf(sig) {
    const f = (sig.factors || []).find((x) => /sequence|trend/i.test(x.name)) || sig.factors?.[0];
    let score = f ? f.score : 50;
    if (sig.active) score = sig.dir === 'BUY' ? Math.max(score, 62) : Math.min(score, 38);
    if (score >= 60) return { word: 'Uptrend', cls: 'up', icon: 'up' };
    if (score <= 40) return { word: 'Downtrend', cls: 'dn', icon: 'dn' };
    return { word: 'Sideways', cls: 'flat', icon: 'flat' };
  }

  const ICON = {
    up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M2 19l4-5 3 3 4-7 3 3 5-7"/><path d="M16 4h5v5"/></svg>',
    dn: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M2 5l4 5 3-3 4 7 3-3 5 7"/><path d="M16 20h5v-5"/></svg>',
    flat: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12h4l3-3 3 3 3-3 3 3h4"/></svg>',
    clock: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round"><circle cx="12" cy="12" r="9"/><path d="M12 7.5v4.8l3 1.8"/></svg>',
    copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 012-2h8"/></svg>',
  };

  /* --------------------------------------------------------------- header */
  let liveUsers = 412 + Math.floor(Math.random() * 40);
  function paintClock() {
    const clock = $('sessionClock');
    if (clock) clock.textContent = hms();
    const lu = $('liveUsers');
    if (lu) lu.textContent = liveUsers;
    const sync = $('scanSync');
    if (sync) sync.textContent = hms();
  }

  function paintPush(date = new Date()) {
    const el = $('lastPush');
    if (!el) return;
    el.textContent = date.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' }) + ', ' + timeLabel(date);
  }

  /* ------------------------------------------------------------- signals */
  function allowedKinds() {
    const set = new Set();
    state.sources.forEach((src) => {
      if (src === 'beast') return;
      (SOURCE_KINDS[src] || []).forEach((k) => set.add(k));
    });
    return set;
  }

  function beastOnly() {
    return state.sources.has('beast');
  }

  /* Beast mode scans everything but only surfaces the setups the engine scores
     at 99%+ — usually 2 to 4 pairs, sometimes fewer, never a full grid. If a
     cycle has nothing that clean we keep the two strongest so it is not empty. */
  function beastRows(rows) {
    const ranked = rows.slice().sort((a, b) => (b.active - a.active) || (b.confidence - a.confidence));
    const clean = ranked.filter((s) => s.confidence >= 99).slice(0, 4);
    return clean.length >= 2 ? clean : ranked.slice(0, 2);
  }

  /* every market is ranked on its own band (top 34% active), exactly like
     the terminal tabs — so OTC shows its own 14/27 split, crypto its own */
  function scoreRows(kind) {
    if (kind !== 'all') {
      try { return M.signals(kind); } catch { return []; }
    }
    const out = [];
    ['otc', 'forex', 'crypto', 'india'].forEach((k) => {
      try { out.push(...M.signals(k)); } catch { /* skip */ }
    });
    return out;
  }

  function listSignals() {
    const kind = state.kind === 'all' ? 'all' : state.kind;
    let rows = scoreRows(kind);

    const allowed = allowedKinds();
    if (allowed.size) rows = rows.filter((s) => allowed.has(s.kind));

    if (state.status === 'active') rows = rows.filter((s) => s.active);
    else if (state.status === 'wait') rows = rows.filter((s) => !s.active);

    // Beast mode = only the near-certain setups, never a full grid
    if (beastOnly()) {
      rows = beastRows(rows);
    } else {
      const order = { otc: 0, forex: 1, crypto: 2, india: 3 };
      rows = rows.slice().sort((a, b) => order[a.kind] - order[b.kind]);
    }
    return rows;
  }

  /* --------------------------------------------------------------- cards */
  const KIND_TAG = { otc: ['OTC', 'o'], forex: ['FX', 'f'], crypto: ['CRYPTO', 'c'], india: ['INR', 'i'] };

  function cardHTML(sig) {
    const trend = trendOf(sig);
    const tag = KIND_TAG[sig.kind] || ['', ''];
    const t = tradeOf(sig.id);
    return `<article class="scan-card" data-id="${sig.id}">
      <div class="sc-head">
        <b class="sc-sym">${sig.symbol}</b><i class="sc-tag ${tag[1]}">${tag[0]}</i>
        <button class="sc-copy" type="button" data-copy="${sig.id}" aria-label="Copy signal">${ICON.copy}Copy</button>
        <span class="sc-feed"><i></i>Real-time feed</span>
      </div>
      <div class="sc-status"><b data-ref="status">WAIT</b><em data-ref="pct"></em><span class="sc-cd" data-ref="cd"></span></div>
      <div class="sc-rows">
        <div class="sc-kv"><span>Trend</span><b data-ref="trend" class="${trend.cls}">${ICON[trend.icon]}${trend.word}</b></div>
        <div class="sc-kv"><span data-ref="l1">Entry · IST</span><b class="time" data-ref="time">${ICON.clock}${t.entry}</b></div>
      </div>
      <i class="sc-accent"></i>
    </article>`;
  }

  function render() {
    const grid = $('scanGrid');
    if (!grid) return;
    const rows = listSignals();
    grid.innerHTML = rows.length
      ? rows.map(cardHTML).join('')
      : '<div class="scan-empty">No pairs match these filters — turn a master-key feed back on.</div>';

    state.entries = new Map();
    Array.from(grid.querySelectorAll('.scan-card')).forEach((card) => {
      state.entries.set(card.dataset.id, {
        card,
        sig: rows.find((r) => r.id === card.dataset.id) || null,
        status: card.querySelector('[data-ref="status"]'),
        pct: card.querySelector('[data-ref="pct"]'),
        trend: card.querySelector('[data-ref="trend"]'),
        time: card.querySelector('[data-ref="time"]'),
        cd: card.querySelector('[data-ref="cd"]'),
        l1: card.querySelector('[data-ref="l1"]'),
      });
    });
    paintCards(rows);
    const count = $('scanCount');
    if (count) count.textContent = String(rows.length);
  }

  function paintCards(rows) {
    rows.forEach((s) => {
      const el = state.entries.get(s.id);
      if (!el) return;
      const trend = trendOf(s);
      const cls = s.active ? (s.dir === 'BUY' ? 'buy' : 'sell') : 'wait';
      el.card.className = `scan-card ${cls}${s.active ? ' active' : ''}`;
      el.status.textContent = s.active ? s.dir : 'WAIT';
      el.pct.textContent = s.active ? Math.round(s.confidence) + '%' : '';
      el.trend.className = trend.cls;
      el.trend.innerHTML = ICON[trend.icon] + trend.word;
      el.sig = s;
    });
    paintTimes();
    const active = rows.filter((s) => s.active).length;
    const nav = $('navActive');
    if (nav) nav.textContent = String(active);
  }

  /* re-stamps each card's entry time once a second (the stamp changes when
     the pair rolls onto its next trade window) */
  function paintTimes() {
    state.entries.forEach((el) => {
      if (!el.sig || !el.time) return;
      const t = tradeOf(el.sig.id);
      el.time.innerHTML = ICON.clock + t.entry;
      if (el.l1) el.l1.textContent = t.pending ? 'Next entry · IST' : 'Entry · IST';
      if (el.cd) el.cd.textContent = t.left;
    });
  }

  function update() {
    const kind = state.kind === 'all' ? 'all' : state.kind;
    let rows = scoreRows(kind);
    const allowed = allowedKinds();
    if (allowed.size) rows = rows.filter((s) => allowed.has(s.kind));
    if (state.status === 'active') rows = rows.filter((s) => s.active);
    else if (state.status === 'wait') rows = rows.filter((s) => !s.active);
    let list = rows;
    if (allowed.size) list = list.filter((s) => allowed.has(s.kind));
    if (beastOnly()) list = beastRows(list);
    if (list.length !== state.entries.size) { render(); return; }
    paintCards(list);
    paintPush();
    state.cycle += 1;
    if (state.cycle % 12 === 0) beep();
  }

  /* --------------------------------------------------------------- copy */
  function copySignal(id) {
    const inst = M.state.byId[id];
    if (!inst) return;
    let sig = null;
    try { sig = M.signalFor(inst); } catch { sig = null; }
    const trend = sig ? trendOf(sig).word : 'Sideways';
    const conf = sig ? Math.round(sig.confidence) : 0;
    const t = tradeOf(id);
    const line = sig && sig.active
      ? `${inst.symbol} ${sig.dir} ${conf}% · ${trend} · entry ${t.entry} IST · ${t.left} left`
      : `${inst.symbol} WAIT · ${trend} · next entry ${t.entry} IST`;
    const done = () => toast(`<b>Copied.</b> ${line}`, 'ok');
    if (navigator.clipboard?.writeText) {
      navigator.clipboard.writeText(line).then(done).catch(fallback);
    } else fallback();
    function fallback() {
      const ta = document.createElement('textarea');
      ta.value = line;
      ta.style.position = 'fixed';
      ta.style.opacity = '0';
      document.body.appendChild(ta);
      ta.select();
      try { document.execCommand('copy'); done(); } catch { toast('Copy blocked by the browser.', 'err'); }
      ta.remove();
    }
  }

  /* -------------------------------------------------------------- wiring */
  function wire() {
    $('kindChips').addEventListener('click', (e) => {
      const b = e.target.closest('button[data-kind]');
      if (!b) return;
      state.kind = b.dataset.kind;
      Array.from($('kindChips').children).forEach((x) => x.classList.toggle('on', x === b));
      render();
    });

    $('statusChips').addEventListener('click', (e) => {
      const b = e.target.closest('button[data-status]');
      if (!b) return;
      state.status = b.dataset.status;
      Array.from($('statusChips').children).forEach((x) => x.classList.toggle('on', x === b));
      render();
    });

    $('masterChips').addEventListener('click', (e) => {
      const b = e.target.closest('button[data-src]');
      if (!b) return;
      const src = b.dataset.src;
      if (state.sources.has(src)) state.sources.delete(src);
      else state.sources.add(src);
      b.classList.toggle('on', state.sources.has(src));
      render();
    });

    $('scanGrid').addEventListener('click', (e) => {
      const btn = e.target.closest('[data-copy]');
      if (btn) {
        e.stopPropagation();
        copySignal(btn.dataset.copy);
      }
    });

    $('moreBtn').addEventListener('click', () => {
      const list = $('moreList');
      const open = list.hidden;
      list.hidden = !open;
      $('moreBtn').setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    $('sideToggle').addEventListener('click', () => $('genSide').classList.toggle('open'));
    $('genSide').addEventListener('click', (e) => { if (e.target.closest('a')) $('genSide').classList.remove('open'); });

    $('signOut').addEventListener('click', () => {
      api.clear();
      try { localStorage.removeItem('otc.beast'); } catch { /* ignore */ }
      window.location.replace('/');
    });

    $('bellBtn').addEventListener('click', () => {
      state.sound = !state.sound;
      toast(state.sound ? '<b>Alerts on.</b> You will hear a beep as the grid rescans.' : 'Alerts muted.', state.sound ? 'ok' : '');
      if (state.sound) beep();
    });
  }

  /* --------------------------------------------------------------- boot */
  async function boot() {
    paintClock();
    paintPush();
    try { await M.init(); } catch { /* local model fallback */ }
    render();
    setInterval(() => {
      paintClock();
      liveUsers = clamp(liveUsers + (Math.random() < 0.5 ? -1 : 1) * Math.floor(Math.random() * 3), 360, 560);
    }, 1000);
    setInterval(update, 5000);
    setInterval(paintPush, 30000);
    /* entries and countdowns tick every second, independent of the 5 s rescan */
    CLOCK.everySecond(paintTimes);
  }

  function init() {
    /* the scanner is readable without a key (it is public market data);
       signing in only unlocks the licence label and the Pro-only modules */
    const plan = api.plan || 'guest';
    const planEl = $('guPlan');
    if (planEl) planEl.textContent = plan === 'pro' ? 'Pro licence' : plan === 'trial' ? 'Trial licence' : 'Guest access';
    wire();
    boot();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
  else init();
})();

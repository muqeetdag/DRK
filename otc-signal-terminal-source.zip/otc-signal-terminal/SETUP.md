# OTC Bot — full source

Institutional Market Confidence Engine™ — static site (no framework, no build tooling
beyond one Node script) plus a CDN boot shell for Vercel.

## What's inside

```
otc-signal-terminal/
├── public/                 # the app itself (what build-static.js copies)
│   ├── index.html          # landing page
│   ├── terminal.html       # OTC Bot grid (signals, filters, detail drawer, chart)
│   ├── generator.html      # Signals / Beast Mode generator
│   ├── scanner.html        # Live Scanner (all pairs, Beast filter)
│   ├── checkout.html       # plans & licences
│   ├── terms.html          # terms & conditions
│   ├── 404.html
│   └── assets/
│       ├── clock.js        # shared market clock — entry/expiry schedule (IST)
│       ├── config.js       # app config, keys, storage helpers
│       ├── market.js       # data layer + 5-factor confidence engine
│       ├── terminal.js     # OTC Bot grid controller
│       ├── generator.js    # Signals / Beast Mode controller
│       ├── scanner.js      # Live Scanner controller
│       ├── landing.js      # landing page controller
│       ├── style.css       # shared styles
│       ├── terminal.css    # grid + detail drawer
│       ├── generator.css   # signals page + chart panel
│       ├── scanner.css     # scanner grid
│       └── favicon.svg
├── shell/                  # Vercel boot shell
│   ├── index.html          # boot screen + pinned build SHA
│   ├── shell.js            # CDN loader (mounts any page, rewrites links)
│   └── *.html              # /scanner /generator /terminal /checkout /terms aliases
├── docs/                   # GitHub-CDN mirror of the built site (jsDelivr/raw)
├── build-static.js         # copies public/ -> static/, inlines asset URLs
├── server.js               # tiny local static server
├── package.json
├── PROJECT.md              # original project readme
└── README.md               # engine/clock/chart architecture notes
```

## Run it locally

```bash
cd otc-signal-terminal
node build-static.js                       # public/ -> static/  (22 files)
cd static && python3 -m http.server 8090   # open http://localhost:8090
```

or:

```bash
node server.js
```

## Deploy (as it runs today)

1. `node build-static.js`
2. `rm -rf docs && cp -r static docs && touch docs/.nojekyll`, commit + push
3. put that commit SHA into `shell/index.html` (`var SHA = '…'`), commit + push
4. on Vercel, deploy `shell/index.html` + the five alias pages as static files

The deployed page never carries the app code itself — `shell/index.html` loads
`docs/assets/shell.js` from jsDelivr (raw.githubusercontent fallback) at the pinned
SHA, then mounts the requested page with its CSS inlined.

## How the timing works

`assets/clock.js` is the single source of truth. Pairs rotate over four candles:
inside its candle a pair enters a few seconds in (offset hashed from the pair id)
and exits one timeframe later, so ~a quarter of the pairs are live at any moment
and the rest point at a real future candle. Stamps are minute-precision IST; the
countdown chip carries the seconds. Scanner, Signals and OTC Bot all read the same
schedule, so a pair never disagrees between pages.

## Engine

`assets/market.js` scores every instrument on five weighted factors (sequence,
momentum, breakout shield, smart-money structure, multi-timeframe confluence) from
live candles when a feed is reachable and from a local simulation otherwise, then
ranks each market so the top ~34% are flagged Active. The 78–99 confidence band is
a rank mapping, not a raw probability.

## Keys (demo build)

- Signals / Beast access key: `OXIDATIVE`
- Trial key: `DEMO-KEY-2025`
- 50 signals per session, history in `localStorage` (`otc.gen.history`)

## Notes

- Charts: forex/crypto/INR use the real TradingView advanced-chart widget
  (`FX:EURUSD`, `OANDA:XAUUSD`, `BINANCE:BTCUSDT`, `FX_IDC:USDINR`); OTC pairs keep
  the engine canvas chart because there is no public feed for them.
- Everything is client-side. There is no backend, database or paid API key in the
  box — `config.js` is where you would wire one in.
